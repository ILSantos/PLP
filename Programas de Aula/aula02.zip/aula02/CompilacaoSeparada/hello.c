/* Parte do exemplo de compilacao separada.
 * Instrucoes no arquivo main.c
 */

#include <stdio.h>

void hello(void)
{
    printf("Hello, world!\n");
}
