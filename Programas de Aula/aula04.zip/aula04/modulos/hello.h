#pragma once

void hello(void);
