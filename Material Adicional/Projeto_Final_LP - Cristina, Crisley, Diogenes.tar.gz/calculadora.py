#! /usr/bin/python
# *-* coding: utf-8 *-* # para reconhecer acentos
#########################################################################################
# calculadora.py v1.0
# data: 11/06/2011
# autores: Crisley Prestes, Cristina Araujo, Diógenes Freitas
# Linguagens de Programacao - UFAM - 2011/1
#########################################################################################


#Código de uma calculadora em Python usando o paradigma procedural da linguagem
#Procuramos deixar o código o mais simples possível
#Para tratar erros de entrada de dados procuramos usar algo que é muito usado em Java, que é o tratamento de excessão 

#TESTADO NO PYTHON V2.7.1 E NO V2.6

import math # biblioteca matemática
import sys	# biblioteca do comando de saída


#funcao para somar 2 números simples
def soma():
	try:
		valor1=input("Digite o primeiro valor:\n")
		valor2=input("Digite o segundo valor:\n")
	except:
		print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
		soma()
	resultado = valor1 + valor2
	print("\n\n\n%f + %f = %f\n\n")%(valor1,valor2,resultado)
	opcao()

#funcao para subtrair 2 números simples
def subtracao():
	try:
		valor1=input("Digite o primeiro valor:\n")
		valor2=input("Digite o segundo valor:\n")
	except:
		print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
		subtracao()
	resultado = valor1 - valor2
	print("\n\n\n%f - %f = %f\n\n")%(valor1,valor2,resultado)
	opcao()


#funcao para multiplicar 2 números simples
def multiplicacao():
	try:
		valor1=input("Digite o primeiro valor:\n")
		valor2=input("Digite o segundo valor:\n")
	except:
		print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
		multiplicacao()
	resultado = valor1 * valor2
	print("\n\n\n%f x %f = %f\n\n")%(valor1,valor2,resultado)
	opcao()


#funcao para dividir 2 números 
def divisao():
	try:
		valor1=input("Digite o primeiro valor:\n")
		valor2=input("Digite o segundo valor:\n")
	except:
		print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
		divisao()
	resultado = valor1 / valor2
	print("\n\n\n%f / %f = %f\n\n")%(valor1,valor2,resultado)
	opcao()


#funcao para encontrar a media de 2 números		
def media():
	try:
		valor1=input("Digite o primeiro valor:\n")
		valor2=input("Digite o segundo valor:\n")
	except:
		print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
		media()
	resultado = (valor1 + valor2)/2
	print("\n\n\nMEDIA entre %f e %f = %f\n\n")%(valor1,valor2,resultado)
	opcao()


#funcao para elevar um numero
def potencia():
	try:
		valor1=input("Digite o valor da base:\n")
		valor2=input("Digite o valor do expoente:\n")
	except:
		print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
		potencia()
	resultado = (valor1 ** valor2)
	print("\n\n\n%f elevado a %f = %f\n\n")%(valor1,valor2,resultado)
	opcao()


#funcao para encontrar raiz quadrada
def raiz():
	try:
		valor1=input("Digite o valor que se deseja encontrar a raiz quadrada:\n")
	except:
		print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
		raiz()
	resultado = math.sqrt(valor1)
	print("\n\n\nraiz quadrada de %f = %f\n\n")%(valor1,resultado)
	opcao()


#Funcao de saihda
def sair():
   print("\n\n\n        TODA A EQUIPE AGRADECE O USO DO APLICATIVO, VOLTE SEMPRE!!! \n")
   sys.exit()

#Encontra o seno de um número
def seno():
   try:
      valor1=input("Digite o valor que se deseja encontrar o SENO:\n")
   except:
      print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
   resultado = math.sin(math.radians(valor1)) # Conversao do valor
   print("\n\n\n SENO %d = %f ")%(valor1,resultado)
   opcao()

#Encontra o cosseno de um número
def cosseno():
   try:
      valor1=input("Digite o valor que se deseja encontrar o COSSENO:\n")
   except:
      print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
   resultado = math.cos(math.radians(valor1))
   print("\n\n\n COSSENO %d = %f ")%(valor1,resultado)
   opcao()


#Encontra a tangente de um número
def tangente():
   try:
      valor1=input("Digite o valor que se deseja encontrar a TANGENTE:\n")
   except:
      print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
   resultado = math.tan(math.radians(valor1))
   print("\n\n\n TANGENTE %d = %f ")%(valor1,resultado)
   opcao()	

#decimal para hexa
def dec2hex():
	try:
		valor1=input("Digite o valor em decimal para hexadecimal :\n")
	except:
		print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
	print("\n\nDEC = %d -> HEXA = %X\n\n") % (valor1,valor1)


# decimal para binario
def dec2bin():
	try:
		valor1=input("Digite o valor em decimal para hexadecimal :\n")
	except:
		print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
	print("\n\n")	
	bin(valor1)	
	print("\n\n")


#def bin2dec():
#	try:
#		valor1=input("Digite o valor em binário para decimal :\n")
#	except:
#		print("\n  ENTRADA DE DADOS INVÁLIDA. TENTE NOVAMENTE \n\n\n")
#	texto="0b"
#	newvalor1 = texto + str(valor1)
#	print("\n\n BINÁRIO PARA DECIMAL : ")
	
#	print("%d")%(newvalor1)
#	int(valor1)
#	print("\n\n")


# Tela principal que eh onde serah escolhido a operacao
def opcao():
   try:
      print("\n\nPOR FAVOR, ESCOLHA A OPCAO DESEJADA\n\n")
      operacao=input("1. SOMA\n2. SUBTRACAO\n3. MULTIPLICACAO\n4. DIVISAO\n5. MEDIA\n6. POTENCIACAO\n7. RAIZ QUAD\n8. BINARIO FUTURO\n9. SENO \n10. COSSENO\n11. TANGENTE \n12. DEC2HEX\n13. DEC2BIN\n14. SAIR\n")
   except:
      print("PERDAO. OPCAO NAO ACEITA \n")
      opcao()
   if (operacao < 1):
      print ("PERDAO. OPCAO NAO ACEITA  \n")
      opcao()
   elif (operacao > 16):
      print ("PERDAO. OPCAO NAO ACEITA \n")
      opcao()
   elif (operacao == 1):
      soma()
   elif (operacao == 2):
      subtracao()
   elif (operacao == 3):
      multiplicacao()
   elif (operacao == 4):
      divisao()
   elif (operacao == 5):
      media()
   elif (operacao == 6):
      potencia()
   elif (operacao == 7):
      raiz()
   elif (operacao == 8):
      print("\n FUTURAMENTE\n\n")
   elif (operacao == 9):
      seno()
   elif (operacao == 10):
      cosseno()
   elif (operacao == 11):
      tangente()
   elif (operacao == 12):
      dec2hex()
   elif (operacao == 13):
      dec2bin()
 #  elif (operacao == 14):
	#	bin2dec()
   elif (operacao == 14):
      sair()		

# Chamando a tela inicial
# Essa funcao deve ficar no final do programa 
opcao()


















