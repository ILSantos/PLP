/* Cristina Araujo
Diogenes Barros
Crisley Prestes
*/

suspeito(lucas).
suspeito(paulo).
suspeito(alex).
suspeito(bernardo).
suspeito(luiz).
alibe(bernardo,lucas).
not(confiavel(alex)).
confiavel(lucas).
confiavel(paulo).
confiavel(bernardo).
confiavel(luiz).
vingarde(paulo,joao).
vingarde(lucas,joao).
herdeiro(bernardo,joao).
herdeiro(joao,luiz).
devia(lucas,joao).
devia(luiz,joao).
foiflagrado(alex,joao).
not(arma(paulo)).
arma(lucas).
arma(alex).
arma(bernardo).
arma(luiz).
/* MOTIVO = devia ou herdeiro ou vingar
MOTIVO -ok
ARMA -ok
NAO_ALIBE sendo que ALIBE_CONFIAVEL - ok
*/


alibeaceito(X):- (alibe(X,Y), confiavel(X)).

matou(X,joao):- (arma(X)),(devia(X,joao);herdeiro(X,joao);vingarde(X,joao);foiflagrado(X,joao)),alibeaceito(X).

/*matou(X,joao):- (arma(X)),(devia(X,joao);herdeiro(X,joao);vingarde(X,joao);foiflagrado(X,joao)),not(confiavel(X)),(alibe(lucas,X);(alibe(bernardo,X))).*/

/*matou(X,joao):- not(confiavel(X)),(alibe(lucas,X);(alibe(bernardo,X))).*/



